const mongoose = require('mongoose');


const SubCategorySchema = mongoose.Schema({
    category_id : {
        type : mongoose.Schema.Types.ObjectId,
        required : true,
        ref : "Category"
    },
    sub_category_name : {
        type : String,
        required : true
    }
    
})



const subcategory = mongoose.model('Subcategory',SubCategorySchema);

module.exports = subcategory;
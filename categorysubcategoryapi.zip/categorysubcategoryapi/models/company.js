const mongoose = require('mongoose');


const CompanySchema = mongoose.Schema({
    company_name : {
        type : String,
        required : true
    }
    
})



const Company = mongoose.model('Company',CompanySchema);
module.exports = Company;
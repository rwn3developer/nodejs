const mongoose = require('mongoose');


const exsubCategorySchema = mongoose.Schema({
    category_id : {
        type : mongoose.Schema.Types.ObjectId,
        required : true,
        ref : "Category"
    },
    sub_category_id : {
        type : mongoose.Schema.Types.ObjectId,
        required : true,
        ref : "Subcategory"
    },
    exsubcategory_name : {
        type : String,
        required : true
    }
 
})



const exsubcategory = mongoose.model('Exsubcategory',exsubCategorySchema);

module.exports = exsubcategory;
const mongoose = require('mongoose');


const UserSchema = mongoose.Schema({
    name : {
        type : String,
        required : true
    },
    email : {
        type : String,
        required : true
    },
    phone : {
        type : String,
        required : true
    },
    city : {
        type : String,
        required : true
    }, 
    salary : {
        type : Number,
        required : true
    },
    company_id : {
        type : mongoose.Schema.Types.ObjectId,
        ref : "Company"
    }
    
})

const User = mongoose.model('User',UserSchema);
module.exports = User;
const express = require('express');

const routes = express.Router();
console.log("routing is working");

const categorycontroller = require('../controllers/CategoryController');

const subcategorycontroller = require('../controllers/SubcategoryController');

const exsubcategorycontroller = require('../controllers/ExsubcategoryController');

const companycontroller = require('../controllers/CompanyController');

const userController = require('../controllers/UserController');

routes.post('/category',categorycontroller.index);
routes.post('/subcategory',subcategorycontroller.index);
routes.post('/exsubcategory',exsubcategorycontroller.index);
routes.get('/viewexsubcategory',exsubcategorycontroller.viewexsubcategory);
routes.post('/company',companycontroller.company);
routes.post('/user',userController.user);
routes.get('/userview',userController.userview);

module.exports = routes;
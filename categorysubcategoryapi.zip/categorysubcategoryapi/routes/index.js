const express = require('express');

const routes = express.Router();
console.log("routing is working");

const categorycontroller = require('../controllers/CategoryController');

const subcategorycontroller = require('../controllers/SubcategoryController');

const exsubcategorycontroller = require('../controllers/ExsubcategoryController');


routes.post('/category',categorycontroller.index);
routes.post('/subcategory',subcategorycontroller.index);
routes.post('/exsubcategory',exsubcategorycontroller.index);

module.exports = routes;
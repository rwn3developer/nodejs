const exsubcategory = require('../models/exsubcategory');

module.exports.index = (req,res) => {

    // console.log(req.body);

    exsubcategory.create({
        category_id : req.body.category_id,
        sub_category_id : req.body.sub_category_id,
        exsubcategory_name : req.body.exsubcategory_name
    },(err,data)=>{
        if(err){
            console.log("Something wrong");
            return false;
        }
        return res.json({status : 1,message : 'exsubcategory successfully insert'});
    })
}
const subcategory = require('../models/subcategory');

module.exports.index = (req,res) => {
    subcategory.create({
        category_id : req.body.category_id,
        sub_category_name : req.body.sub_category_name
    },(err,data)=>{
        if(err){
            console.log("Something wrong");
            return false;
        }
        return res.json({status : 1,message : 'subcategory successfully insert'});
    })
}
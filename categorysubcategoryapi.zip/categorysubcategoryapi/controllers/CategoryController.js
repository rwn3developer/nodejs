const category = require('../models/category');

module.exports.index = (req,res) => {
    category.create({
        category_name : req.body.category_name
    },(err,data)=>{
        if(err){
            console.log("Something wrong");
            return false;
        }
        return res.json({status : 1,message : 'category successfully insert'});
    })
}
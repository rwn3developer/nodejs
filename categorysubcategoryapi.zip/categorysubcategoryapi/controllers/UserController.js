const user = require('../models/user');
const company = require('../models/company');

module.exports.user = (req,res) => {
    user.create({
        name : req.body.name,
        email : req.body.email,
        phone : req.body.phone,
        city : req.body.city,
        salary : req.body.salary,
        company_id : req.body.company_id
    },(err,data)=>{
        if(err){
            console.log("User not add");
            return false;
        }
        return res.json({status : 1,messege : "User successfully add"});
    })
}

module.exports.userview = (req,res) => {
    user.aggregate([{
        
            $lookup : {
                from : "companies",
                localField : "company_id",
                foreignField : "_id",
                as : "user"
            }
        },
        {
            $unwind : "$user"
        },
        { 
            $project : { _id : 1, name : 1,"user.company_name" : 1}
        },],(err,data)=>{
            return res.json(data);
         })
        
    
}
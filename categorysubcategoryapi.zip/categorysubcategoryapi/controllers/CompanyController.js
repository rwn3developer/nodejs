
const Company = require('../models/company');

module.exports.company = (req,res) => {
    Company.create({
        company_name : req.body.company_name
    },(err,data)=>{
        if(err){
            console.log("Company not insert");
            return false;
        }
        return res.json({status : "1",messege : "Company successfully insert"});
    })
}